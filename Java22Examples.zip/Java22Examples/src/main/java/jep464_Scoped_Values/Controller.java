package jep464_Scoped_Values;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class Controller {

    private final Service service;

    public Controller(final Service service) {
        this.service = service;
    }

    public void consumingMethod()
    {
        if (ScopedValuesExample.REQUEST_TIME.isBound())
            System.out.println("consumingMethod() -- request Time: " +
                               ScopedValuesExample.REQUEST_TIME.get());

        service.consumingMethod();
    }

    public String process()
    {
        if (ScopedValuesExample.REQUEST_TIME.isBound())
            System.out.println("process() -- request Time: " +
                               ScopedValuesExample.REQUEST_TIME.get());

        return service.process();
    }
}
