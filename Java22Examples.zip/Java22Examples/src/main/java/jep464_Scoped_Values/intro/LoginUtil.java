package jep464_Scoped_Values.intro;


/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class LoginUtil
{
    private final XyzService service = new XyzService();

    public static final ScopedValue<User> LOGGED_IN_USER =
                                          ScopedValue.newInstance();

    public void performLogin(final Request request)
    {
        User loggedInUser = authenticateUser(request);
        ScopedValue.where(LOGGED_IN_USER, 
                          loggedInUser).run(() -> service.performAction());
    }

    private User authenticateUser(Request request) {
        return new User("FALLBACK", "PWD".toCharArray());
    }


    public static void main(final String[] args) throws Exception {

        new LoginUtil().performLogin(new Request("Some Apples"));
    }
}