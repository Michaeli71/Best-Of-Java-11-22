package jep457_Class_File_Api.bonus;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class ExampleDebug {

    public static void main(final String[] args) {
        debugOutput1();
        debugOutput2();
        System.out.println("Normal Statement");
    }

    public static void debugOutput1()
    {
        System.out.println("Some JEPs");
    }

    public static void debugOutput2()
    {
        System.out.println("Noch mehr JEPs");
    }

}
