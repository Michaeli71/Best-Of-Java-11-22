package jep457_Class_File_Api.bonus;

import com.sun.source.tree.MethodInvocationTree;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.classfile.*;
import java.lang.classfile.instruction.InvokeInstruction;
import java.lang.invoke.MethodHandle;
import java.nio.file.Path;

/*
Nehmen wir an, wir wollen aus dem Bytecode, also der Klassendatei, alle Methoden entfernen,
die mit dem Startkürzel \code{debug} gekennzeichnet sind. Alles andere soll unverändert bleiben.
Basierend auf den Bytes der Klassendatei wird ein \code{ClassModel} erzeugt. Dieses können
wir über die Methode \code{build()} wird ein \code{ClassBuilder} erzeugt und
es erfolgt die Angabe einer Transformationsvorschrift für die vorzunehmenden Modifikationen.
Dazu durchläuft man alle Elemente vom Typ \code{ClassElement} des \code{ClassModel} und
prüft auf Debug-Methoden und gibt alles andere an den \code{ClassBuilder} weiter:

Aber Achtung: Es werden nur die Methodendefinitionen entfernt, potenzielle Aufrufe nicht!
 */
public class TransformerDebugRemove {
    public static void main(String[] args) throws IOException {

        ClassFile cf = ClassFile.of();
        ClassModel classModel = cf.parse(Path.of("target/classes/jep457_Class_File_Api/bonus/ExampleDebug.class"));
        byte[] newBytes = cf.build(classModel.thisClass().asSymbol(),
                classBuilder -> {
                    for (ClassElement ce : classModel) {

                        // Step 1:
                        if (!isDebugMethod(ce)) {
                            classBuilder.with(ce);
                        }

                        // Step 2: Problem das ist bestandteil vom CodeModel
                        /*
                        if (!isDebugMethodInvocation(ce)) {
                            classBuilder.with(ce);
                        }
                        */
                    }
                });

        // write without debug methode
        new File("jep457_Class_File_Api_Modified").mkdir();
        try (var fos = new FileOutputStream("jep457_Class_File_Api_Modified/ExampleDebug.class")) {
            fos.write(newBytes);
        }
    }

    private static boolean isDebugMethod(ClassElement ce) {
        return ce instanceof MethodModel methodModel &&
                methodModel.methodName().stringValue().startsWith("debug");
    }

    /*private static boolean isDebugMethodInvocation(ClassElement ce) {
        return ce instanceof InvokeInstruction ii && ii.method().name().stringValue().startsWith("debug");
    }
     */
}
