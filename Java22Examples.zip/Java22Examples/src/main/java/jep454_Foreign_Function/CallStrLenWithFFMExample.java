package jep454_Foreign_Function;

import java.lang.foreign.*;

import static java.lang.foreign.ValueLayout.ADDRESS;
import static java.lang.foreign.ValueLayout.JAVA_LONG;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class CallStrLenWithFFMExample
{
    public static void main(final String[] args) throws Throwable
    {
        // 1. SymbolLookup für gebräuchliche Bibliotheken ermitteln
        var linker = Linker.nativeLinker();
        final SymbolLookup stdlib = linker.defaultLookup();

        // 2. MethodHandle für "strlen" in der C Standard Library ermitteln
        var strlenMethodHandle = linker.downcallHandle(
                                 stdlib.find("strlen").orElseThrow(),
                                        FunctionDescriptor.of(JAVA_LONG, ADDRESS));

        // 3. Java in C String umwandeln und in C-Speicher bereitstellen
        final Arena auto = Arena.ofAuto();
        var strMemorySegment = auto.allocateFrom("direct c call of strlen");

        // 4. Aufruf der "foreign function"
        final long len = (long) strlenMethodHandle.invoke(strMemorySegment);

        System.out.println("len = " + len);
        // 5. Speicher wird durch "Arena.ofAuto()" automatisch aufgeräumt
    }
}