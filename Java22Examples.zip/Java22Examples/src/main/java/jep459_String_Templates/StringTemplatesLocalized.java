package jep459_String_Templates;

import java.util.FormatProcessor;
import java.util.List;
import java.util.Locale;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class StringTemplatesLocalized
{
    public static void main(final String[] args)
    {
        var deLocale = Locale.of("de");
        localSpecificCalculations(deLocale);

        // spezielle Zeichen
        var thaiLocale = Locale.forLanguageTag("th-TH-u-nu-thai");
        localSpecificCalculations(thaiLocale);
        // // spezielle Zeichen sowie von rechts nach links
        var arLocale = Locale.of("ar");
        localSpecificCalculations(arLocale);
    }

    private static void localSpecificCalculations(final Locale locale) {
        var localeFMT = FormatProcessor.create(locale);

        for (int y : List.of(10, 100, 1000)) {
            for (int x = 1; x < 8; x++) {
                String result = localeFMT."%4d\{x} + %4d\{y} = %5d\{x + y}";
                System.out.println(result);
            }
        }
    }
}

