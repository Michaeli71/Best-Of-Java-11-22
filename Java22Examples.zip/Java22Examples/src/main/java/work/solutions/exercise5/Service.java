package work.solutions.exercise5;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class Service {

    public void consumingMethod()
    {
        var user = ScopedValuesExample.LOGGED_IN_USER.orElse(new User("n/a", "n/a"));

        System.out.println("Consumer: " + user);
    }

    public String process()
    {
        // wenn null, dann leider isBound() auch true
        if (ScopedValuesExample.LOGGED_IN_USER.isBound() && ScopedValuesExample.LOGGED_IN_USER.get() == null)
            throw new IllegalStateException("expected to be bound");

        if (ScopedValuesExample.LOGGED_IN_USER.get().name().startsWith("ADMIN"))
            return "ACCESS GRANTED!";
        else
            return "Top Secret Processing ... no access to ScopedValue granted";
    }

    public void processRequestOldStyle(final User loggedInUser) {
        System.out.println("processRequestOldStyle: " + loggedInUser);
    }
}
