package work.solutions.exercise1;

import java.awt.*;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class ColoredShape {
    private final Color color;
    private final int x;
    private final int y;

    public ColoredShape(Color color, int x, int y) {
        this.color = color;
        this.x = x;
        this.y = y;
    }
}

