package misc_api;

import javax.lang.model.SourceVersion;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21/22" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 * <p>
 * Copyright 2021/22/23/24 by Michael Inden
 */
public class Java22RuntimeVersionExample
{
	public static void main(final String[] args)
	{
		System.out.println("Runtime required for this: " + 
	                       SourceVersion.RELEASE_22.runtimeVersion());
		System.out.println("latest: " + SourceVersion.latest());
		System.out.println("valueOf: " + SourceVersion.valueOf("RELEASE_22"));

		System.out.println(SourceVersion.latest().runtimeVersion());
		System.out.println(SourceVersion.latest().name());
	}
}