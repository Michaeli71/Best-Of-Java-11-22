package a_questions;

import java.util.stream.Stream;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 *
 * @author Michael Inden
 *
 * Copyright 2023 by Michael Inden
 */
public class StreamNpeExample {
    public static void main(String[] args) {
        Stream.of("A", "B", null, "D", "E").
                map(str -> str.repeat(5)).
                toList();
    }
}
