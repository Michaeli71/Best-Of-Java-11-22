package solutions.part1;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class Exercise04_Records 
{
	record Square(double sideLength) {}

	record Circle(double radius) {}
}
