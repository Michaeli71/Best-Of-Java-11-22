package b_slides.java21.syntax.jep441_switch_pattern_matching;

interface Shape {}

record Rectangle(int x, int y, int width, int height) implements Shape {}

record Triangle(int area) implements Shape {}