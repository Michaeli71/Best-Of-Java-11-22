package b_slides.java21.syntax.qualified_enums;

sealed interface Direction permits CompassDirection, PlayerDirection {}

enum CompassDirection implements Direction {NORTH, SOUTH, EAST, WEST}

enum PlayerDirection implements Direction {UP, DOWN, LEFT, RIGHT}