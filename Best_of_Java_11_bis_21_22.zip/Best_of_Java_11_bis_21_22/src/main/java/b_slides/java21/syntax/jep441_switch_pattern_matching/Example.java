package b_slides.java21.syntax.jep441_switch_pattern_matching;

public class Example
{
    public static void main(String[] args) {
        handleTriangleAndRectangle(new Triangle(7271));
        handleTriangleAndRectangle(new Triangle(71));
        handleTriangleAndRectangle(new Rectangle(0, 0, 20, 7));
        handleTriangleAndRectangle(new Rectangle(0, 0, 200, 7));
    }

    static void handleTriangleAndRectangle(final Shape shape)
    {
        switch (shape)
        {
            case Triangle triangle when triangle.area() > 100 ->
                    System.out.println("big triangle");
            case Triangle triangle when triangle.area() > 50 &&
                    triangle.area() <= 100  ->
                    System.out.println("medium triangle");
            case Rectangle rect when rect.width() > 100 || rect.height() > 100 ->
                    System.out.println("big rect");
            default -> System.out.println("Something else: " + shape);
        }
    }

}
