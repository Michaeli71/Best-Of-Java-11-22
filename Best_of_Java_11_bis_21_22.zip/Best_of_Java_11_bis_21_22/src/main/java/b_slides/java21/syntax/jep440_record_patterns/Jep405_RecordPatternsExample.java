package b_slides.java21.syntax.jep440_record_patterns;

/**
 * Sample program for the workshop "Best of Java 11 to 21" / the book "Java 21 LTS - the innovations"
 *
 * @author Michael Inden
 *
 * Copyright 2023 by Michael Inden
 */
public class Jep405_RecordPatternsExample
{
    record Point(int x, int y) {}

    static void printCoordinateInfo(Object obj)
    {
        if (obj instanceof Point point)
        {
            int x = point.x();
            int y = point.y();

            System.out.println("x: %d, y: %d, sum: %d".formatted(x, y, x + y));
        }
    }

    static void printCoordinateInfoNew(Object obj)
    {
        if (obj instanceof Point(int x, int y))
        {
            System.out.println("x: %d, y: %d, sum: %d".formatted(x, y, x + y));
        }
    }
    
    public static void main(String[] args)
    {
        printCoordinateInfo(new Point(72, 71));
        printCoordinateInfoNew(new Point(72, 71));
    }
}