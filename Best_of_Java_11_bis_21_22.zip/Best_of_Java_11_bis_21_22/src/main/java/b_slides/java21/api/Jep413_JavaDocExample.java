package b_slides.java21.api;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class Jep413_JavaDocExample
{
    /**
     * The following code shows how to use {@code Optional.isPresent} and
     * {@code Optional.get} in combination
     * 
     * {@snippet :
     * if (optValue.isPresent()) // @highlight substring="isPresent"
     * { 
     *     System.out.println("value: " + optValue.get()); // @highlight substring="get"
     * } }
     */
    public static void newJavaDocExample(String[] args)
    {
        // 
        //
        //
        //
    }
}