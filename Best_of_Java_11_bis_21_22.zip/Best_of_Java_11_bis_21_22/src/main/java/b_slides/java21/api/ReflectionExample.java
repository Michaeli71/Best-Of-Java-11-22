package b_slides.java21.api;

import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodHandles.Lookup;
import java.lang.invoke.VarHandle;
import java.lang.reflect.Field;
import java.util.Arrays;

public class ReflectionExample 
{
	public static void main(final String[] args) throws ReflectiveOperationException
	{
		accessFieldOldStyle("Java 18 Rocks");
		accessFieldNewStyle("Java 18 Rocks");
	}

	private static void accessFieldOldStyle(final String input) throws ReflectiveOperationException
	{
		var field = String.class.getDeclaredField("value");
		field.setAccessible(true);

		var byteValues = (byte[]) field.get(input);
		System.out.println(Arrays.toString(byteValues));
	}

	private static void accessFieldNewStyle(final String input) throws ReflectiveOperationException
	{
		var lookup = MethodHandles.privateLookupIn(String.class,
				MethodHandles.lookup());
		var handle = lookup.findVarHandle(String.class, "value", byte[].class);

		var byteValues = (byte[]) handle.get(input);
		System.out.println(Arrays.toString(byteValues));
	}
}