package b_slides.java21;

import javax.lang.model.SourceVersion;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class Java21RuntimeVersionExample 
{
	public static void main(final String[] args)
	{
		System.out.println("Runtime required for this: " + 
	                       SourceVersion.RELEASE_21.runtimeVersion());
		System.out.println("latest: " + SourceVersion.latest());
		System.out.println("valueOf: " + SourceVersion.valueOf("RELEASE_21"));

		System.out.println(SourceVersion.latest().runtimeVersion());
		System.out.println(SourceVersion.latest().name());
	}
}