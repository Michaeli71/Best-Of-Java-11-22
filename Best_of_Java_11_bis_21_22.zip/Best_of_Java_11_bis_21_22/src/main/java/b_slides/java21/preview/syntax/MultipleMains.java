package b_slides.java21.preview.syntax;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class MultipleMains {

    protected static void main() {
        System.out.println("protected static void main()");
    }

    public void main(String[] args) {
        System.out.println("public void main(String[] args)");
    }
}
