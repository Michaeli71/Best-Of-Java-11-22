package b_slides.java17.syntax.sealed_types;

final class Open extends BaseCommand
	{
		@Override
		public void action() {
			System.out.println("OPEN");
		}
	}

