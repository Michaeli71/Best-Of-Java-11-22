package b_slides.java17.syntax.records;

import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

import com.fasterxml.jackson.core.JsonProcessingException;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class RecordInterfaceExample
{
    public static void main(String[] args) throws JsonProcessingException
    {
		record SimplePerson(String name, int age, String city) {}
		
		Set<SimplePerson> speakers = new HashSet<>();
		speakers.add(new SimplePerson("Michael", 51, "Zürich"));
		speakers.add(new SimplePerson("Michael", 51, "Zürich"));
		speakers.add(new SimplePerson("Anton", 42, "Aachen"));
		
		System.out.println(speakers);

        // -------------------
        
		Set<SimplePerson> sortedSpeakers = new TreeSet<>();
		sortedSpeakers.add(new SimplePerson("Michael", 51, "Zürich"));
		sortedSpeakers.add(new SimplePerson("Michael", 51, "Zürich"));
		sortedSpeakers.add(new SimplePerson("Anton", 42, "Aachen"));
		   
		System.out.println(sortedSpeakers);
    }
}
