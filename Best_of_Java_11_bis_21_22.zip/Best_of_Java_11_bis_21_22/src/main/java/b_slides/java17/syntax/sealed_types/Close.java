package b_slides.java17.syntax.sealed_types;

final class Close extends BaseCommand {
    @Override
    public void action() {
        System.out.println("CLOSE");
    }
}