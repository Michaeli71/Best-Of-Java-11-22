package b_slides.java17.syntax.sealed_types;

sealed abstract class BaseCommand permits Open, Close, UserDefinedCommand {
    public abstract void action();
}