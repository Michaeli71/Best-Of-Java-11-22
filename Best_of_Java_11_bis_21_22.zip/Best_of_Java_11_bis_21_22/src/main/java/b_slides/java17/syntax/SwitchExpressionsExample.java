package b_slides.java17.syntax;

import java.time.DayOfWeek;

/**
 * Beispielprogramm für die Workshops "Best of Java 11 - 21" und das
 * Buch "Java – Die Neuerungen in Version 17 LTS, 18 und 19"
 *
 * @author Michael Inden
 *         <p>
 *         Copyright 2021/22/23 by Michael Inden
 */
public class SwitchExpressionsExample {
    public static void main(final String[] args) {
        DayOfWeek day = DayOfWeek.SUNDAY;

        int numOfLetters = switch (day) {
            case MONDAY, FRIDAY, SUNDAY -> {
                if (day == DayOfWeek.SUNDAY)
                    System.out.println("SUNDAY is FUN DAY");
                yield 6;
            }
            case TUESDAY -> 7;
            case THURSDAY, SATURDAY -> 8;
            case WEDNESDAY -> 9;
        };
        System.out.println(numOfLetters);
    }

}
