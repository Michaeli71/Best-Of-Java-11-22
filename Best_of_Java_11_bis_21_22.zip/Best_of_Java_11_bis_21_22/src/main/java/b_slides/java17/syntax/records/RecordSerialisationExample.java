package b_slides.java17.syntax.records;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class RecordSerialisationExample
{
    public static void main(String[] args) throws JsonProcessingException
    {
        final ObjectMapper mapper = new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT);

        //var person = new Person("John", "Doe", "USA", LocalDate.of(1991, 3, 29), List.of("Speaker"));
        var person = new Person("John", "Doe", "USA", new Date(), List.of("Speaker"));
        //var person = new Person("John", "Doe", "USA", new Date(), List.of("Speaker"));

        var serializedJson = mapper.writeValueAsString(person);
        System.out.println(serializedJson);
        
        var person2 = new Person2("John", "Doe", "USA", LocalDate.of(1991, 3, 29), List.of("Speaker"));

        var serializedJson2 = mapper.writeValueAsString(person2);
        System.out.println(serializedJson2);       

    }
}
