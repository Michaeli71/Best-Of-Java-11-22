package b_slides.java17.syntax.records;

import java.util.Comparator;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class RecordInterfaceExample3
{
    public static void main(String[] args)  
    {
		record SimplePerson3(String name, int age, String city) 
		       implements Comparable<SimplePerson3>
		{
			static Comparator<SimplePerson3> byAllAttributes = Comparator.
					                        comparing(SimplePerson3::name).
		                                    thenComparingInt(SimplePerson3::age).
		                                    thenComparing(SimplePerson3::city);
			
			@Override
			public int compareTo(SimplePerson3 other) 
			{				
				return byAllAttributes.compare(this, other);
			}
		}
		
		Set<SimplePerson3> speakers = new HashSet<>();
		speakers.add(new SimplePerson3("Michael", 51, "Zürich"));
		speakers.add(new SimplePerson3("Michael", 51, "Zürich"));
		speakers.add(new SimplePerson3("Michael", 49, "Zürich"));
		speakers.add(new SimplePerson3("Anton", 42, "Aachen"));
		
		System.out.println(speakers);

        // -------------------
        
		Set<SimplePerson3> sortedSpeakers = new TreeSet<>();
		sortedSpeakers.add(new SimplePerson3("Michael", 51, "Zürich"));
		sortedSpeakers.add(new SimplePerson3("Michael", 51, "Zürich"));
		sortedSpeakers.add(new SimplePerson3("Michael", 49, "Zürich"));
		sortedSpeakers.add(new SimplePerson3("Anton", 42, "Aachen"));
		   
		System.out.println(sortedSpeakers);
    }
}
