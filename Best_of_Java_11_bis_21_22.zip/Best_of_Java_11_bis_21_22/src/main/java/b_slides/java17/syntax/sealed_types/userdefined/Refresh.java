package b_slides.java17.syntax.sealed_types.userdefined;

import b_slides.java17.syntax.sealed_types.UserDefinedCommand;

public class Refresh extends UserDefinedCommand {
    @Override
    public void action() {
        System.out.println("Refresh");
    }
}