package b_slides.java17.syntax;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class VarSpecial {

	public static void main(String[] args) {

		Runnable runner1 = new Runnable() {
			public final String info = "INACCESSIBLE";

			@Override
			public void run() {
			}
			
			public String getInfo()
			{
				return "OTHER INFO";
			}
		};
//		System.out.println(runner1.info);
//		System.out.println(runner1.getInfo());

		
		var runner2 = new Runnable() {
			public final String info = "ACCESSIBLE WITH VAR";

			@Override
			public void run() {
			}
			
			public String getInfo()
			{
				return "OTHER INFO WITH VAR";
			}
		};
		System.out.println(runner2.getClass());
		System.out.println(runner2.info);
		System.out.println(runner2.getInfo());					
	}
}
