package b_slides.java17.syntax.sealed_types;

// Extension Point
public non-sealed abstract class UserDefinedCommand extends BaseCommand {
}

