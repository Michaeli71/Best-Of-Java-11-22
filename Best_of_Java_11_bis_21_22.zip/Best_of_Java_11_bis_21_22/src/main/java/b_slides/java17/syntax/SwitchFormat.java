package b_slides.java17.syntax;

import java.time.DayOfWeek;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class SwitchFormat
{
    public static void main(String[] args)
    {
        DayOfWeek day = DayOfWeek.FRIDAY;
        int numLetters = switch (day)
        {
            case MONDAY, FRIDAY, SUNDAY -> 6;
            case TUESDAY -> 7;
            case THURSDAY, SATURDAY -> 8;
            case WEDNESDAY -> 9;
        };
    }
}
