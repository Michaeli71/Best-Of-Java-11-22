package b_slides.java17.syntax.records;

import java.time.LocalDate;

/**
 * Beispielprogramm für den Workshop "Java 11 bis 20" / das Buch "Java 21 LTS – die Neuerungen"
 * 
 * @author Michael Inden
 * 
 * Copyright 2023 by Michael Inden 
 */
public class RecordImmutabilityExample4
{
    public static void main(String[] args)  
    {
		record DateRange(LocalDate start, LocalDate end) 
		{
			DateRange
			{
				if (!start.isBefore(end))
					throw new IllegalArgumentException("start >= end");
			}
		}
				
		DateRange range1 = new DateRange(LocalDate.of(1971,1,7), LocalDate.of(1971,2,27));
		System.out.println(range1);
		
		DateRange range2 = new DateRange(LocalDate.of(1971,6,7), LocalDate.of(1971,2,27));
		System.out.println(range2);
    }
}
